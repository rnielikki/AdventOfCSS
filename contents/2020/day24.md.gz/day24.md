﻿# title is not content
this shouldn't be opened!

But you opened it anyway, so:

|  name  |  usage                        | returns                     |
|--------|-------------------------------|-----------------------------|
|  Bind  | func.bind(this, a, b ...)     | bound function              |
|  Call  | func.call(this, a, b ...)     | result of function call     |
|  Apply | func.apply(this, [a, b, ...]) | result of function call     |
